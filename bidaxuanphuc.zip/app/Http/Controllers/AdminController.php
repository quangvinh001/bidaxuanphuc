<?php

namespace App\Http\Controllers;

use App\Models\Bill;
use Illuminate\Http\Request;
use Carbon\Carbon;
use Illuminate\Support\Facades\Gate;

class AdminController extends Controller
{
    public function index()
    {
        if (Gate::allow("check")) {
            $latestMonth = Bill::orderBy('created_at', 'desc')->firstOrFail()->created_at->month;
            $latestYear = Bill::orderBy('created_at', 'desc')->firstOrFail()->created_at->year;

            $firstDayOfLatestMonth = Carbon::createFromDate($latestYear, $latestMonth, 1);
            $lastDayOfLatestMonth = $firstDayOfLatestMonth->copy()->lastOfMonth();

            $totalAmount = Bill::whereBetween('created_at', [$firstDayOfLatestMonth, $lastDayOfLatestMonth])->sum('total');

            $period = $firstDayOfLatestMonth->format('F Y'); // Tên tháng và năm

            $totalyear = Bill::where('trangthai', '=', '1')->sum('total');
            return view('admin.dashboard', compact('totalAmount', 'period', 'totalyear'));
        } else {
            // Người dùng không có quyền admin
            return abort(403, 'Unauthorized');
        }
    }
}
