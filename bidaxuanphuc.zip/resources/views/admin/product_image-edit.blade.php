<x-app-layout>
    <div class="header-title"><span>Sửa Hình Ảnh</span></div>
</x-app-layout>
