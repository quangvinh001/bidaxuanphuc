@extends('layout_home.master')
@section('content')
    <div class="card card-solid">
        <div class="row">
            <div class="col-lg-6">
                @if (count($images) > 0)
                    <div id="productCarousel" class="carousel slide" data-ride="carousel">
                        <div class="carousel-inner product">
                            @foreach ($images as $key => $image)
                                <div class="carousel-item{{ $loop->first ? ' active' : '' }}">
                                    <img id="zoom-image" src="{{ asset('build/images/' . $image->path) }}"
                                        class="d-block w-100" alt="{{ $product->name }}">
                                </div>
                            @endforeach
                        </div>
                        <button class="carousel-control-prev" type="button" data-bs-target="#productCarousel"
                            data-bs-slide="prev">
                            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                            <span class="visually-hidden">Previous</span>
                        </button>
                        <button class="carousel-control-next" type="button" data-bs-target="#productCarousel"
                            data-bs-slide="next">
                            <span class="carousel-control-next-icon" aria-hidden="true"></span>
                            <span class="visually-hidden">Next</span>
                        </button>
                    </div>
                    <div class="row">
                        <div class="col-3">
                            <div class="mt-3 d-flex flex-nowarp">
                                @foreach ($images as $key => $image)
                                    <img src="{{ asset('build/images/' . $image->path) }}"
                                        alt="Thumbnail {{ $key + 1 }}"
                                        class="product-image-thumb thumbnail-img{{ $key === 0 ? ' active' : '' }}"
                                        onclick="currentSlide({{ $key + 1 }})">
                                @endforeach
                            </div>
                        </div>
                    </div>
                @else
                    <div id="productCarousel" class="carousel slide" data-ride="carousel">
                        <div class="carousel-inner product">
                            <div class="carousel-item active">
                                <img id="zoom-image" src="{{ asset('build/images/' . $product->image) }}"
                                    class="d-block w-100" alt="{{ $product->name }}">
                            </div>
                        </div>
                        <button class="carousel-control-prev" type="button" data-bs-target="#productCarousel"
                            data-bs-slide="prev">
                            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                            <span class="visually-hidden">Previous</span>
                        </button>
                        <button class="carousel-control-next" type="button" data-bs-target="#productCarousel"
                            data-bs-slide="next">
                            <span class="carousel-control-next-icon" aria-hidden="true"></span>
                            <span class="visually-hidden">Next</span>
                        </button>
                    </div>
                @endif
            </div>
            <div class="col-lg-6  ">
                <form method="POST" action="{{ route('themgiohang', $product->id) }}">
                    @csrf
                    <h3 class="my-3 fw-bolder">{{ $product->name }}</h3>
                    <hr>
                    <div class="form-group">
                        <label for="quantity">Số lượng:</label>
                        <input type="number" id="quantity" name="soluong" value="1" min="1">
                    </div>
                    <div class=" py-2 px-3 mt-4">
                        @if ($product->promotion_price != 0)
                            <h3 class="mb-0">
                                <span class="flash-sale">{{ number_format($product->promotion_price) }} đ</span>
                            </h3>
                            <h5 class="mt-0">
                                <small> <span class="flash-del">{{ number_format($product->unit_price) }} đ</span> </small>
                            </h5>
                        @endif
                    </div>

                    <div class="mt-4">
                        <button class="add-to-cart btn btn-outline-primary btn-lg btn-flat"> <i
                                class="fas fa-cart-plus fa-lg mr-2"></i>
                            Thêm vào giỏ hàng</button>
                    </div>
                </form>
            </div>
        </div>
        <div class="row mt-4">
            <nav class="w-100">
                <div class="nav nav-tabs" id="product-tab" role="tablist">
                    <a class="nav-item nav-link active" id="product-desc-tab" data-toggle="tab"
                        data-bs-target="#product-desc" role="tab" aria-controls="product-desc" aria-selected="true">Mô
                        tả</a>
                    <a class="nav-item nav-link" id="product-comments-tab" data-toggle="tab"
                        data-bs-target="#product-comments" role="tab" aria-controls="product-comments"
                        aria-selected="false">Bình Luận</a>

                </div>
            </nav>
            <div class="tab-content p-3" id="nav-tabContent">
                <div class="tab-pane fade show active" id="product-desc" role="tabpanel"
                    aria-labelledby="product-desc-tab">
                    {{ $product->description }}
                </div>
                <div class="tab-pane fade" id="product-comments" role="tabpanel" aria-labelledby="product-comments-tab">
                    Vivamus rhoncus nisl sed venenatis luctus. Sed condimentum
                </div>
            </div>
        </div>
        <!-- /.card-body -->
    </div>
    <script>
        $(document).ready(function() {
            // Activate ElevateZoom on the zoom-image element
            $('#zoom-image').elevateZoom({
                gallery: 'productCarousel',
                cursor: 'pointer',
                galleryActiveClass: 'active',
                imageCrossfade: true,
                loadingIcon: 'path/to/elevatezoom/loading.gif', // Replace with the actual path to the loading icon
            });
        });

        function currentSlide(n) {
            $('#productCarousel').carousel(n - 1);

            // Remove 'active' class from all thumbnails
            $('.thumbnail-img').removeClass('active');

            // Add 'active' class to the clicked thumbnail
            $(`.thumbnail-img:nth-child(${n})`).addClass('active');
        }
    </script>
@endsection
