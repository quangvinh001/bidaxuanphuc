@extends('layout_home.master')
@section('content')
<div class="name-card">
    <a class="danh-muc" href="#">{{ $category->name }}</a>
    <span>{{ $category->description }}</span>
</div>
<div class="row row-cols-2 row-cols-sm-2 row-cols-md-4 row-cols-lg-5">
    @foreach ($products as $products)
        <div class="col">
            <a href="{{ route('chitietsanpham', $products->id) }}">
                <div class="card">
                    <div class="card-sale">{{ $products->discount_percentage }}%</div>
                    <div class="card-layout">
                        <img src="/build/images/{{ $products->image }}" class="card-image" alt="...">
                        <div class="card-body">
                            <p class="card-title"><span>{{ $products->name }}</span></p>
                            <p class="card-gia">
                                <span class="flash-del">{{ number_format($products->unit_price) }} đ</span>
                                <span class="flash-sale">{{ number_format($products->promotion_price) }} đ</span>
                            </p>
                        </div>
                    </div>
                </div>
            </a>

        </div>

        @endforeach
</div>
{{-- {{ $categories->links() }} --}}

@endsection
