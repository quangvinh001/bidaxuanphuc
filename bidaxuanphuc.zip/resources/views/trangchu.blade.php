@extends('layout_home.master')
@section('content')
    <div class="name-card">
        <a class="danh-muc" href="#">Sản Phẩm Mới</a>
    </div>
    <div class="row row-cols-2 row-cols-sm-2 row-cols-md-4 row-cols-lg-5">
        @foreach ($new_products as $new)
            <div class="col">
                <a href="{{ route('chitietsanpham', $new->id) }}">
                    <div class="card">
                        <div class="card-sale">{{ $new->discount_percentage }}%</div>
                        <div class="card-layout">
                            <img src="/build/images/{{ $new->image }}" class="card-image" alt="...">
                            <div class="card-body">
                                <p class="card-title"><span>{{ $new->name }}</span></p>
                                <p class="card-gia">
                                    <span class="flash-del">{{ number_format($new->unit_price) }} đ</span>
                                    <span class="flash-sale">{{ number_format($new->promotion_price) }} đ</span>
                                </p>
                            </div>
                        </div>
                    </div>
                </a>

            </div>
        @endforeach
        {{ $new_products->links() }}
    </div>
    @foreach ($categories as $product_types)
        <div class="name-card">
            <a class="danh-muc" href="#">{{ $product_types->name }}</a>
            <span>{{ $product_types->description }}</span>
        </div>
        <div class="row row-cols-2 row-cols-sm-2 row-cols-md-4 row-cols-lg-5">
            @foreach ($product_types->products as $products)
                <div class="col">
                    <a href="{{ route('chitietsanpham', $products->id) }}">
                        <div class="card">
                            <div class="card-sale">{{ $products->discount_percentage }}%</div>
                            <div class="card-layout">
                                <img src="/build/images/{{ $products->image }}" class="card-image" alt="...">
                                <div class="card-body">
                                    <p class="card-title"><span>{{ $products->name }}</span></p>
                                    <p class="card-gia">
                                        <span class="flash-del">{{ number_format($products->unit_price) }} đ</span>
                                        <span class="flash-sale">{{ number_format($products->promotion_price) }} đ</span>
                                    </p>
                                </div>
                            </div>
                        </div>
                    </a>

                </div>
            @endforeach
        </div>
        {{ $categories->links() }}
    @endforeach
@endsection
