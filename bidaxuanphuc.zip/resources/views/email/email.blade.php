Tiêu đề email :  <span>{{$name}},{{$email}} </span>
Nội dung liên hệ :

<h3>{{ $messages}}</h3>

<h4>{{$name}}, {{$phone}}</h4>